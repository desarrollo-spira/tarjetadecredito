# JMV 2022-04-29

El almacenamiento del scorm fue movido a esta ruta, ya que daba error de cache y o reprodución en el video introductorio.

/app2/httpd/09-pwa-misfinanzasencasa/browser/assets/tdc/CO

https://misfinanzasencasa.davivienda.com/assets/tdc/CO/curso-tdc/scormcontent/index.html#/lessons/r-jSB78lN_6uKTiU00B5ywjv2wKlOrEg